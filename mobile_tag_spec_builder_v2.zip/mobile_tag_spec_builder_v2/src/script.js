new Vue({
  el: "#app",
  data: {
    showInstructions: true,
    actionType: "trackAction", // Default action type
    keyValuePairs: []
  },
  computed: {
    swiftCode() {
      const payload = this.buildPayload();
      if (this.actionType === "trackAction") {
        return `MobileCore.track(action: "sampleAction", data: ${JSON.stringify(
          payload,
          null,
          2
        )})`;
      } else if (this.actionType === "trackState") {
        return `MobileCore.track(state: "sampleState", data: ${JSON.stringify(
          payload,
          null,
          2
        )})`;
      } else {
        return `let xdmData: [String: Any] = ${JSON.stringify(
          payload,
          null,
          2
        )}\nEdge.sendEvent(experienceEvent: ExperienceEvent(xdm: xdmData))`;
      }
    },
    androidCode() {
      const payload = this.buildPayload();
      if (this.actionType === "trackAction") {
        return `MobileCore.trackAction("sampleAction", ${JSON.stringify(
          payload,
          null,
          2
        )});`;
      } else if (this.actionType === "trackState") {
        return `MobileCore.trackState("sampleState", ${JSON.stringify(
          payload,
          null,
          2
        )});`;
      } else {
        return `Map<String, Object> xdmData = ${JSON.stringify(
          payload,
          null,
          2
        )};\nExperienceEvent experienceEvent = new ExperienceEvent.Builder()\n  .setXdmSchema(xdmData)\n  .build();\nEdge.sendEvent(experienceEvent, null);`;
      }
    }
  },
  methods: {
    toggleInstructions() {
      this.showInstructions = !this.showInstructions;
    },
    setActionType(type) {
      this.actionType = type;
    },
    addPair() {
      this.keyValuePairs.push({ key: "", value: "" });
    },
    removePair(index) {
      this.keyValuePairs.splice(index, 1);
    },
    buildPayload() {
      return this.keyValuePairs.reduce((acc, pair) => {
        if (pair.key && pair.value) acc[pair.key] = pair.value;
        return acc;
      }, {});
    },
    copyToClipboard(content) {
      navigator.clipboard.writeText(content).then(
        () => alert("Copied to clipboard! 🎉"),
        () => alert("Failed to copy content.")
      );
    }
  }
});
